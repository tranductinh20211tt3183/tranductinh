const start = document.querySelector('.start');
const timeout = document.querySelector('.timeout');
const score = document.querySelector('#score');
let score1 = 0;
//Tạo 100 hình tròn
let createCircle = () => {
    for(let i = 1 ; i <= 100 ; i++ ){
       document.body.insertAdjacentHTML("beforeend",'<div class="number">'+i+'</div>')
    }
}
createCircle();
//Tạo ngẫu nhiên
const number = document.querySelectorAll('.number');

let getRndInteger = (min, max) => {
    return Math.floor(Math.random() * (max - min)) + min;
}
//Viet hàm hình tròn
let setPosition = () => {
    number.forEach((item) => {
        let x =  getRndInteger(0,1350);
        let y = getRndInteger(0,600);
        item.style.left = x + 'px';
        item.style.top = y  + 'px';
    })
}
//Ham hết giờ
let timeout1 = () => {
    timeout.style.display = 'block';
    score.innerHTML += score1;  
}
//Khi onclick  thì sẽ xuất hiện hình tròn
start.onclick = () => {
    setPosition();
    setTimeout(timeout1, 10000);
    start.style.display = 'none';
}
//Khi click lên number từ số 1 đến 100
number.forEach((item) => {
    item.onclick = () => {
        if(item.innerHTML == score1 + 1){
            item.classList.add('black');
            score1 = score1 + 1;
        }
    }
})