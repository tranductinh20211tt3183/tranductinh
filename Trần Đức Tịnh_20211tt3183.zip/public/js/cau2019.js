let getRandomIntlusive = (min, max) => {
    min = Math.ceil(min);
    max = Math.floor(max);
    return Math.floor(Math.random() * (max - min + 1)) + min;
}
let result;
//2. ham tao phep toan ngau nhien
let createOperator = () => {
    let x, y, o;
    let op = ['+', '-'];
    x = getRandomIntlusive(0, 99);
    y = getRandomIntlusive(0, 99);
    o = op[getRandomIntlusive(0, 1)];
    result = eval(x + o + y);
    return x + o + y;
}
let c = createOperator();
const start = document.querySelector('#btn-start');
//3. ham tao circle
let createCircle = () => {
    game.insertAdjacentHTML("beforeend", "<div class='circle'>" + result + "</div>");
    for(let i = 1; i <= 9; i++) {
        j = getRandomIntlusive(-99,198);
        game.insertAdjacentHTML("beforeend", "<div class='circle'>" + j + "</div></div>")
    }
}
createCircle();
const circle = document.querySelectorAll('.circle');
//4.ham set vi tri
let setPosition = () => {
    circle.forEach((item) => {
        item.style.left = getRandomIntlusive(0, 1100) + 'px';
        item.style.top = getRandomIntlusive(0, 500) + 'px';
    })
}
const operation = document.querySelector('#operation');
//5. su kien click chuot len nut start
start.onclick = () => {
    operation.innerHTML = c;
    setPosition();
}
