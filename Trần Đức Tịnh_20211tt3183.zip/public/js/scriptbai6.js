const number = document.querySelectorAll('.number');
const start = document.querySelector('.start');
const timeout1 = document.querySelector('.timeout');
const score = document.querySelector('#score');
let score1 = 0;
let getRndInteger = (min, max) => {
    return Math.floor(Math.random() *(max - min)) + min;
}
//
let setpost = () => {
    number.forEach((item) => {
        item.style.left = getRndInteger(0, 390) + 'px';
        item.style.top = getRndInteger(0, 507) + 'px';
    })
}
let timeout = () => {
    clearInterval(t);
    timeout1.style.display = 'block';
    score.innerHTML += score;
}
start.onclick = () => {
    setpost();
    t = setInterval(setpost ,1000);
    setTimeout(timeout,10000);
    start.style.display = 'none';
}
number.forEach((item) => {
    item.onclick = () => {
        score1 += +item.innerHTML;
    }
})
